extends Position2D

export (Array, PackedScene)var enemies
# Declare mem ber variables here. Examples:
# var a = 2
# var b = "text"


# Called when the node enters the scene tree for the first time.
func _ready():
	randomize()
	global_position = Vector2(rand_range(70,1920-70),rand_range(70,1080-70))
	pass # Replace with function body.

func spawn_enemy():
	var enemy = enemies[int(rand_range(0, enemies.size()-0.1))].instance()
	enemy.max_hp = int(rand_range(2,3+int(Global.score/1000)))
	enemy.rejuvinate()
	get_parent().add_child(enemy)
	enemy.global_position = global_position
	queue_free()
	pass

# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(delta):
#	pass


func _on_spawn_timer_timeout():
	spawn_enemy()
	pass # Replace with function body.

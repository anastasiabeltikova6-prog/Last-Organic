extends Node2D


# Declare member variables here. Examples:
# var a = 2
# var b = "text"


# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.
var space_amm = 0

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	if Input.is_action_just_pressed("ui_accept") and space_amm == 0:
		$story.hide()
		$gameplay.show()
		space_amm += 1
	elif Input.is_action_just_pressed("ui_accept") and space_amm == 1:
		get_tree().change_scene("res://tscn/game.tscn")
	pass

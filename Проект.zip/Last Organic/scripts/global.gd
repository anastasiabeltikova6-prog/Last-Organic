extends Node


# Declare member variables here. Examples:
# var a = 2
# var b = "text"

var player_node
var last_score = 0
var score = 0
var score_to_next_upgrade = 500
var curr_score = 0
# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.



func uppgrades_update():
	var add_score = score-last_score
	curr_score += add_score
	if player_node:
		if curr_score >= score_to_next_upgrade:
			player_node.upgrades += 1
			curr_score = 0
	last_score = score
	pass
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta):
	uppgrades_update()
	pass

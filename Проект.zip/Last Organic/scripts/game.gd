extends Node2D


# Declare member variables here. Examples:
# var a = 2
# var b = "text"

var spawner = load("res://tscn/misc/enemy_spawner.tscn")
# Called when the node enters the scene tree for the first time.
func _ready():
	Global.score = 0
	Global.curr_score = 0
	pass # Replace with function body.
var spawn_time_default = 5.0
var curr_time = 0.0
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	curr_time += delta
	var new_spawn_time = spawn_time_default-clamp(float(Global.score)/2000.0,0, 4)
	if curr_time >= new_spawn_time:
		curr_time = 0.0
		spawn_enemy()
	pass

func spawn_enemy():
	if Global.player_node:
		if Global.player_node.is_living:
			var new_spawner = spawner.instance()
			get_parent().add_child(new_spawner)

extends Projectile_universal

export var radius_actual = 80.0
# Declare member variables here. Examples:
# var a = 2
# var b = "text"


# Called when the node enters the scene tree for the first time.
func _ready():
	dir = Vector2.ZERO
	speed = 0.0
	scale = Vector2(radius_actual/80.0,radius_actual/80.0)
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta):
	scale = Vector2(radius_actual/80.0,radius_actual/80.0)
	pass


func _on_explosion_body_entered(body):
	on_hit(body)
	pass # Replace with function body.

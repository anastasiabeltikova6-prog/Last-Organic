extends Area2D

class_name Projectile_universal

export (String, "player_side", "enemy_side") var side = "enemy_side"
export (int) var damage = 1
export (float) var speed = 50000.0
export (Vector2) var dir = Vector2.ZERO
export (int) var max_collisions = 1
export (float) var ricoshet_chance = 0.0
export (float) var explosion_chance = 0.0
export (float) var explosion_radius = 10.0
export (float) var explosion_damage = 10.0
export (PackedScene) var explosion_scene
export (float) var life_time = 10.0
export (float) var init_time = 0.1
var current_life_time = 0.0
var current_collisions = 0

func get_class():
	return "projectile"
# Declare member variables here. Examples:
# var a = 2
# var b = "text"
func on_hit(body:Object):
	if current_life_time > init_time or body.get_class() != "projectile":
		if body.get_class() == "mob":
			if body.get_side() != side:
				body.damage(damage)
		current_collisions += 1
		var ricoshet = rand_range(0,100)
		if ricoshet_chance >= ricoshet:
			var new_bullet = self.duplicate()
			new_bullet.current_collisions = max_collisions + 1
			new_bullet.init_time += init_time+0.5
			new_bullet.current_life_time = current_life_time
			new_bullet.dir = Vector2.ZERO.direction_to(Vector2(rand_range(-100,100),rand_range(-100,100)))
			new_bullet.global_position = global_position
			get_parent().call_deferred("add_child",new_bullet)
		var explosion = rand_range(0,100)
		if explosion_chance >= explosion:
			var new_explosion = explosion_scene.instance()
			new_explosion.global_position = global_position
			new_explosion.damage = explosion_damage
			new_explosion.radius_actual = explosion_radius
			get_parent().call_deferred("add_child",new_explosion)
		if current_collisions >= max_collisions:
			queue_free()
	pass

# Called when the node enters the scene tree for the first time.
func _ready():
	randomize()
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	position += dir*speed*delta
	current_life_time += delta
	if current_life_time > life_time:
		queue_free()
	pass



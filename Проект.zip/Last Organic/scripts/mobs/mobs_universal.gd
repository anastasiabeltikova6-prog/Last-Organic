extends KinematicBody2D
class_name Mob_Universal


export (float) var max_hp = 1.0
export (float) var current_hp = 1.0

export (String, "player_side", "enemy_side") var side = "enemy_side"
var is_living = true
export var is_damagable = true 
# Declare member variables here. Examples:
# var a = 2
# var b = "text"
func get_class():
	return "mob"

func rejuvinate():
	current_hp = max_hp

func get_side():
	return side
# Called when the node enters the scene tree for the first time.
func _ready():
	current_hp = max_hp
	pass # Replace with function body.

func damage(damage_amount):
	if is_damagable:
		current_hp -= damage_amount

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta):
	current_hp = clamp(current_hp, 0, max_hp)
	is_living = current_hp > 0.0
	pass

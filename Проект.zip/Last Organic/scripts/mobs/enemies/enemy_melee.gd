extends Mob_Universal

export var score = 100
export var max_movement_speed = 70000.0
export var accel = 1000.0
var current_movement_speed_vec = Vector2.ZERO
export var distance_to_dash = 500.0
export var dash_mult = 2.0
export var dash_time = 0.5
export var dash_load_time = 0.5
var dash_direction = Vector2.ZERO
var states = ["approaching", "preparing_to_dash", "dashing"]
var state = states[0]
# Declare member variables here. Examples:
# var a = 2
# var b = "text"
var player

# Called when the node enters the scene tree for the first time.
func _ready():
	$sprite_base.show()
	$hp_label.show()
	pass # Replace with function body.

func update_labels():
	$hp_label.text = str(current_hp)

func update_scale():
	scale = Vector2(float(max_hp)/3.0,float(max_hp)/3.0)
	pass


func update_timers():
	$timers/dash_load_timer.wait_time = dash_load_time
	$timers/dash_timer.wait_time = dash_time
	pass

func movement(delta):
	if is_living:
		$trail_base.active = state == states[2]
		if Global.player_node:
			player = Global.player_node
			if state == states[0]:
				current_movement_speed_vec += global_position.direction_to(player.global_position)*accel
				current_movement_speed_vec = current_movement_speed_vec.clamped(max_movement_speed)
			if global_position.distance_to(player.global_position) < distance_to_dash and state == states[0]:
				state = states[1]
				current_movement_speed_vec = Vector2.ZERO
				dash_direction = global_position.direction_to(player.global_position)
			if state == states[1] and $timers/dash_load_timer.time_left == 0:
				$timers/dash_load_timer.start()
				current_movement_speed_vec = Vector2.ZERO
				pass
			if state == states[2] and $timers/dash_timer.time_left == 0:
				$timers/dash_timer.start()
				current_movement_speed_vec = dash_direction*max_movement_speed*dash_mult
			move_and_slide(current_movement_speed_vec*delta)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	update_labels()
	update_scale()
	update_timers()
	movement(delta)
	if not is_living:
		$sprite_base.hide()
		$hp_label.hide()
		if $timers/death_timer.time_left == 0:
			$timers/death_timer.start()
			$death_expl.emitting = true
	pass


func _on_dash_load_timer_timeout():
	state = states[2]
	pass # Replace with function body.


func _on_dash_timer_timeout():
	state = states[0]
	pass # Replace with function body.


func _on_death_timer_timeout():
	Global.score += score
	queue_free()
	pass # Replace with function body.


func _on_damage_box_body_entered(body):
	if body.get_class() == "mob":
			if body.get_side() != side:
				body.damage(1)
	pass # Replace with function body.

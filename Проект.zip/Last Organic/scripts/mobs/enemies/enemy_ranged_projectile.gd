extends Mob_Universal


# Declare member variables here. Examples:
# var a = 2
# var b = "text"
export (PackedScene)var bullet_scene
export var score = 100


# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.

var can_shoot = false

func shoot():
	if is_living:
		var new_bullet = bullet_scene.instance()
		new_bullet.global_position = $rotation_point/gun_point.global_position
		new_bullet.dir = global_position.direction_to($rotation_point/gun_point.global_position)
		get_parent().add_child(new_bullet)
	pass

func update_labels():
	$hp_label.text = str(current_hp)

func update_scale():
	scale = Vector2(float(max_hp)/2.0,float(max_hp)/2.0)
	pass

func basic_combat():
	if is_living and Global.player_node:
		var player = Global.player_node
		if player.current_hp > 0:
			$rotation_point.look_at(player.global_position)
	pass

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta):
	basic_combat()
	update_labels()
	update_scale()
	if not is_living and $timers/death_timer.time_left == 0:
		$rotation_point.hide()
		$hp_label.hide()
		$death_expl.emitting = true
		$timers/death_timer.start()
	pass


func _on_bullet_cd_timeout():
	shoot()
	pass # Replace with function body.


func _on_death_timer_timeout():
	Global.score += score
	queue_free()
	pass # Replace with function body.

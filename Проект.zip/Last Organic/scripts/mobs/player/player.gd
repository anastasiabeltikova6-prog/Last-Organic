extends Mob_Universal

#MOVEMENT
export var move_speed = 40000.0
export var dash_speed_mult = 5.0
export var dash_time = 0.2
export (float,0.01,500) var stamina_reload_time = 2.0
export var max_stamina = 3
var current_stamina = 3
#COMBAT
export (float,0.01,500) var shoot_cooldown = 0.75
export var max_magazine_capacity = 7
var current_bullet_count = 7
export var reload_time = 1.5
export (float,0,100)var split_shot_chance = 1.0
export var split_shot_ammount = 2
export var weapon_damage_and_accuracy = 75.0
export (float,0,100) var explosion_chance = 5.0
export var explosion_radius = 80.0
export var explosion_damage = 20.0
export (float,0,100) var ricoshet_chance = 5.0
export(PackedScene) var bullet_scene


export var next_level_score = 100
# Declare member variables here. Examples:
# var a = 2
# var b = "text"
export var player_level = 1
export var upgrades = 0
var is_dashing = false
var can_shoot = true

func update_ui():
	$ui/stamina_label.text = "ВЫНОСЛИВОСТЬ: "+str(current_stamina)+"/"+str(max_stamina)+"/"+str("%.2f" % $timers/stamina_cd.time_left)
	$ui/life_label.text = "ЖИЗНЬ: "+str(current_hp)+"/"+str(max_hp)
	$ui/current_ammo_label.text = "КОЛ-ВО  ПУЛЬ: "+str(current_bullet_count)+"/"+str(max_magazine_capacity)+"/"+str("%.2f" % $timers/reload_cd.time_left)
	$ui/score_label.text = "СЧЁТ: "+str(Global.score)
	$ui/upgrades_label.text = "КОЛ-ВО  УЛУЧШЕНИЙ: "+str(upgrades)
	pass


func update_timers():
	$timers/stamina_cd.wait_time = stamina_reload_time
	$timers/bullet_cd.wait_time = shoot_cooldown
	$timers/reload_cd.wait_time = reload_time
	$timers/dash_timer.wait_time = dash_time

func check_stamina():
	if current_stamina != max_stamina and $timers/stamina_cd.time_left == 0:
		$timers/stamina_cd.start()
		pass

func movement(delta):
	var x_dir = int(Input.is_action_pressed("ui_right")) - int(Input.is_action_pressed("ui_left")) 
	var y_dir = int(Input.is_action_pressed("ui_down")) - int(Input.is_action_pressed("ui_up")) 
	var dir = Vector2(x_dir,y_dir).clamped(1)
	if Input.is_action_just_pressed("DASH") and not is_dashing and current_stamina != 0:
		is_dashing = true
		current_stamina -= 1
		$timers/dash_timer.start()
	if is_dashing:
		move_and_slide(dir*move_speed*dash_speed_mult*delta)
		collision_layer = 2
		collision_mask = 2
	else:
		move_and_slide(dir*move_speed*delta)
		collision_layer = 1
		collision_mask = 1
	$dash_paticles.emitting = is_dashing
	pass

func combat():
	$gun_rotator.look_at(get_global_mouse_position())
	if Input.is_action_pressed("SHOOT") and can_shoot and current_bullet_count != 0:
		var split_shot = rand_range(0,100)
		if split_shot_chance >= split_shot:
			for i in range(0, split_shot_ammount):
				spawn_bullet()
		else:
			spawn_bullet()
		can_shoot = false
		current_bullet_count -= 1
		$timers/bullet_cd.start()
	if Input.is_action_just_pressed("RELOAD") and $timers/reload_cd.time_left == 0:
		current_bullet_count = 0
	if current_bullet_count == 0 and $timers/reload_cd.time_left == 0:
		$timers/reload_cd.start()
	pass

func spawn_bullet():
	var bullet = bullet_scene.instance()
	bullet.ricoshet_chance = ricoshet_chance
	bullet.explosion_chance = explosion_chance
	bullet.explosion_damage = explosion_damage
	bullet.explosion_radius = explosion_radius
	bullet.global_position = $gun_rotator/bullet_point.global_position
	bullet.dir = $gun_rotator.global_position.direction_to($gun_rotator/bullet_point.global_position)
	var recoil = 100.0-clamp(weapon_damage_and_accuracy,0,100)
	bullet.dir += Vector2(recoil*rand_range(-1,1)/100,recoil*rand_range(-1,1)/100)
	bullet.damage = ceil(weapon_damage_and_accuracy/75.0)
	get_parent().add_child(bullet)
	bullet.global_position = $gun_rotator/bullet_point.global_position
	pass

# Called when the node enters the scene tree for the first time.
func _ready():
	$ui/upgrades.hide()
	$ui_basic/screen_cover.hide()
	$ui.show()
	$ui_basic/ending.hide()
	Global.player_node = self
	randomize()
	current_stamina = max_stamina
	current_bullet_count = max_magazine_capacity
	pass # Replace with function body.

func update_death_screen():
	$ui_basic/ending/final_score.text = "ФИНАЛЬНЫЙ СЧЁТ: " + str(Global.score)
	var text = ""
	text += "МАКС. HP: " + str(max_hp) + ", "
	text += "УРОН И ТОЧНОСТЬ: " + str(weapon_damage_and_accuracy) + " (урон: " + str(int(ceil(weapon_damage_and_accuracy / 75.0))) + "), "
	text += "СКОРОСТРЕЛЬНОСТЬ (КД): " + str("%.2f" % shoot_cooldown) + " сек, "
	text += "ПЕРЕЗАРЯДКА: " + str("%.2f" % reload_time) + " сек, "
	text += "ОБОЙМА: " + str(max_magazine_capacity) + " патр., "
	text += "СТАМИНА (МАКС): " + str(max_stamina) + ", "
	text += "ВОССТ. СТАМИНЫ: " + str("%.2f" % stamina_reload_time) + " сек, "
	text += "СПЛИТШОТ: шанс " + str(split_shot_chance) + "%, пуль " + str(split_shot_ammount) + ", "
	text += "ШАНС ВЗРЫВА: " + str(explosion_chance) + "%, "
	text += "УРОН ВЗРЫВА: " + str(explosion_damage) + ", "
	text += "РАДИУС ВЗРЫВА: " + str(explosion_radius) + ", "
	text += "ШАНС РИКОШЕТА: " + str(ricoshet_chance) + "%, "
	$ui_basic/ending/upgrades_level.text = text
	pass


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	if is_living:
		update_upgrades()
		movement(delta)
		check_stamina()
		update_timers()
		update_ui()
		combat()
	else:
		if Input.is_action_just_pressed("ui_accept"):
			get_tree().change_scene("res://tscn/intro.tscn")
		update_death_screen()
		$ui_basic/screen_cover.show()
		$ui.hide()
		$ui_basic/ending.show()
	pass

var last_up_amm = 0

func update_upgrades():
	if upgrades != last_up_amm:
		do_upgrade()
	last_up_amm = upgrades
	pass

func _on_stamina_cd_timeout():
	current_stamina += 1
	pass # Replace with function body.


func _on_bullet_cd_timeout():
	can_shoot = true
	pass # Replace with function body.


func _on_reload_cd_timeout():
	current_bullet_count = max_magazine_capacity
	pass # Replace with function body.


func _on_dash_timer_timeout():
	is_dashing = false
	pass # Replace with function body.

func do_upgrade():
	var options = [
		"shoot_cooldown", "reload_time", "stamina_reload_time",
		"max_stamina", "max_magazine_capacity", "split_shot_ammount",
		"split_shot_chance", "explosion_chance", "ricoshet_chance",
		"weapon_damage_and_accuracy", "explosion_radius", "explosion_damage",
		"max_hp"
	]
	var choice = options[randi() % options.size()]
	var lbl_text = ""
	
	match choice:
		"shoot_cooldown":
			var old = shoot_cooldown
			shoot_cooldown = max(0.1, shoot_cooldown - rand_range(0.05, 0.15))
			lbl_text = "СКРСТРЛНСТЬ -" + str("%.2f" % (old - shoot_cooldown))
		"reload_time":
			var old = reload_time
			reload_time = max(0.1, reload_time - rand_range(0.05, 0.20))
			lbl_text = "ПЕРЕЗАРЯДКА -" + str("%.2f" % (old - reload_time))
		"stamina_reload_time":
			var old = stamina_reload_time
			stamina_reload_time = max(0.1, stamina_reload_time - rand_range(0.05, 0.20))
			lbl_text = "ВОССТ. СТАМИНЫ -" + str("%.2f" % (old - stamina_reload_time))
		"max_stamina":
			var v = 1
			max_stamina += v
			current_stamina = max_stamina
			lbl_text = "СТАМИНА +" + str("%.2f" % float(v))
		"max_magazine_capacity":
			var v = int(rand_range(1, 4))
			max_magazine_capacity += v
			lbl_text = "ОБОЙМА +" + str("%.2f" % float(v))
		"split_shot_ammount":
			var v = 1
			split_shot_ammount += v
			lbl_text = "СПЛИТШОТ +" + str("%.2f" % float(v)) + " пуля"
		"split_shot_chance":
			var old = split_shot_chance
			split_shot_chance = min(100, split_shot_chance + int(rand_range(5, 16)))
			lbl_text = "ШАНС СПЛИТШОТА +" + str("%.2f" % (split_shot_chance - old)) + "%"
		"explosion_chance":
			var old = explosion_chance
			explosion_chance = min(100, explosion_chance + int(rand_range(5, 16)))
			lbl_text = "ШАНС ВЗРЫВА +" + str("%.2f" % (explosion_chance - old)) + "%"
		"ricoshet_chance":
			var old = ricoshet_chance
			ricoshet_chance = min(100, ricoshet_chance + int(rand_range(5, 16)))
			lbl_text = "ШАНС РИКОШЕТА +" + str("%.2f" % (ricoshet_chance - old)) + "%"
		"weapon_damage_and_accuracy":
			var v = int(rand_range(5, 16))
			weapon_damage_and_accuracy += v
			lbl_text = "УРОН И ТОЧНОСТЬ +" + str("%.2f" % float(v))
		"explosion_radius":
			var v = int(rand_range(10, 31))
			explosion_radius += v
			lbl_text = "РАДИУС ВЗРЫВА +" + str("%.2f" % float(v))
		"explosion_damage":
			var v = int(rand_range(5, 16))
			explosion_damage += v
			lbl_text = "УРОН ВЗРЫВА +" + str("%.2f" % float(v))
		"max_hp":
			max_hp += 1
			current_hp += 1
			lbl_text = "МАКС. HP +" + str("%.2f" % 1.0)
	
	$ui/upgrades/upgrade/lbl.text = lbl_text
	$ui/upgrades.show()
	$timers/upgrade_timer.start()
	pass


func _on_upgrade_timer_timeout():
	$ui/upgrades.hide()
	pass # Replace with function body.

signal banner_state_changed
signal interstitial_state_changed
signal rewarded_state_changed
signal advanced_banners_state_changed

var minimum_delay_between_interstitial setget , _minimum_delay_between_interstitial_getter
var is_banner_supported setget , _is_banner_supported_getter
var banner_state setget , _banner_state_getter
var is_interstitial_supported setget , _is_interstitial_supported_getter
var interstitial_state setget , _interstitial_state_getter
var is_rewarded_supported setget , _is_rewarded_supported_getter
var rewarded_state setget , _rewarded_state_getter
var rewarded_placement setget , _rewarded_placement_getter
var is_advanced_banners_supported setget , _is_advanced_banners_supported_getter
var advanced_banners_state setget , _advanced_banners_state_getter


func _minimum_delay_between_interstitial_getter():
	return _js_advertisement.minimumDelayBetweenInterstitial

func _is_banner_supported_getter():
	return _js_advertisement.isBannerSupported
	
func _banner_state_getter():
	return _js_advertisement.bannerState

func _is_interstitial_supported_getter():
	return _js_advertisement.isInterstitialSupported

func _interstitial_state_getter():
	return _js_advertisement.interstitialState

func _is_rewarded_supported_getter():
	return _js_advertisement.isRewardedSupported

func _rewarded_state_getter():
	return _js_advertisement.rewardedState

func _rewarded_placement_getter():
	return _js_advertisement.rewardedPlacement

func _is_advanced_banners_supported_getter():
	return _js_advertisement.isAdvancedBannersSupported

func _advanced_banners_state_getter():
	return _js_advertisement.advancedBannersState

var _js_advertisement = null
var _js_on_banner_state_changed = JavaScript.create_callback(self, "_on_banner_state_changed")
var _js_on_interstitial_state_changed = JavaScript.create_callback(self, "_on_interstitial_state_changed")
var _js_on_rewarded_state_changed = JavaScript.create_callback(self, "_on_rewarded_state_changed")
var _js_on_advanced_banners_state_changed = JavaScript.create_callback(self, "_on_advanced_banners_state_changed")
var _utils = load("res://addons/playgama_bridge/utils.gd").new()
var _check_adblock_callback = null
var _js_check_adblock_then = JavaScript.create_callback(self, "_on_js_check_adblock_then")
var _js_check_adblock_catch = JavaScript.create_callback(self, "_on_js_check_adblock_catch")


func set_minimum_delay_between_interstitial(value):
	_js_advertisement.setMinimumDelayBetweenInterstitial(value)

func show_banner(position = Bridge.BannerPosition.BOTTOM, placement = null):
	_js_advertisement.showBanner(position, placement)

func hide_banner():
	_js_advertisement.hideBanner()

func show_interstitial(placement = null):
	_js_advertisement.showInterstitial(placement)

func show_rewarded(placement = null):
	_js_advertisement.showRewarded(placement)

func show_advanced_banners(placement = null):
	_js_advertisement.showAdvancedBanners(placement)

func hide_advanced_banners():
	_js_advertisement.hideAdvancedBanners()

func check_adblock(callback):
	if _check_adblock_callback != null:
		return
	
	_check_adblock_callback = callback

	_js_advertisement.checkAdBlock() \
		.then(_js_check_adblock_then) \
		.catch(_js_check_adblock_catch)


func _init(js_advertisement):
	_js_advertisement = js_advertisement
	_js_advertisement.on('banner_state_changed', _js_on_banner_state_changed)
	_js_advertisement.on('interstitial_state_changed', _js_on_interstitial_state_changed)
	_js_advertisement.on('rewarded_state_changed', _js_on_rewarded_state_changed)
	_js_advertisement.on('advanced_banners_state_changed', _js_on_advanced_banners_state_changed)

func _on_banner_state_changed(args):
	emit_signal("banner_state_changed", args[0])

func _on_interstitial_state_changed(args):
	emit_signal("interstitial_state_changed", args[0])

func _on_rewarded_state_changed(args):
	emit_signal("rewarded_state_changed", args[0])

func _on_advanced_banners_state_changed(args):
	emit_signal("advanced_banners_state_changed", args[0])

func _on_js_check_adblock_then(args):
	if _check_adblock_callback != null:
		var data = args[0]
		var data_type = typeof(data)
		match data_type:
			TYPE_BOOL:
				_check_adblock_callback.call_func(data)
			_:
				_check_adblock_callback.call_func(false)
		_check_adblock_callback = null

func _on_js_check_adblock_catch(args):
	if _check_adblock_callback != null:
		_check_adblock_callback.call_func(false)
		_check_adblock_callback = null
